import React, { useEffect, useState } from "react";
import axios from 'axios';
import {useNavigate} from 'react-router-dom'
import { useUserContext } from "../contexts/UserContext";

const Successpage = () => {
  const { user, selectedPlan } = useUserContext();
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');


  const navigate = useNavigate();


  useEffect(() => {
    console.log("success", user, selectedPlan);
    saveUserDetails();
  }, [user, selectedPlan]);

  const saveUserDetails = async () => {
    try {
      const usersaveURL = process.env.REACT_APP_USER_SAVE_URL;
  
      const response = await axios.post(usersaveURL, {
        user,
        selectedPlan
      }, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
  
      if (response.status === 200) {
        // console.log(response.data.message);
        setSuccessMessage('User successfully registered');
      } else {
        console.error('Error saving data to the server:', response.statusText);
        if (response.data && response.data.message) {
          setErrorMessage(response.data.message);
        }
      }
    } catch (error) {
      console.error('Error saving data to the server:', error.message);
      if (error.response && error.response.data && error.response.data.message) {
        setErrorMessage(error.response.data.message);
      }
    }
  };

  const handleLoginRedirect = () => {
    navigate("/");
  };

  const handlePricingRedirect=()=>{
    navigate("/pricing");
  }

  return (
    <div>
      {successMessage ? (
        <div>
          <h2>Success !</h2>
          <p>{successMessage}</p>
          <div>
          <button className="btn btn-primary" onClick={handleLoginRedirect}>
                Login
              </button>
          </div>
        </div>
      ) : (
        <div>
          <h4>{errorMessage && errorMessage}</h4>
        <div><button className="btn btn-primary" onClick={handlePricingRedirect}>
                Select Plan
              </button></div>
        </div>
      )}
    </div>
  );
};

export default Successpage;
