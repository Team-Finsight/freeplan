import React, { useEffect, useState } from "react";
import { Link,useNavigate } from "react-router-dom";
import { useUserContext } from "../../contexts/UserContext";

const Pricing = () => {
  const [selectedPlan, setSelectedplan] = useState(null);
  const [userDetails, setUserDetails] = useState(null);

  const { updateSelectedPlan, user } = useUserContext();

  const navigate = useNavigate();

  const handleSelectPlan = (plan) => {
    setSelectedplan(plan);
    updateSelectedPlan(plan);
    console.log("selected plan", selectedPlan);
  };

  const createFreeUser = () => {
     console.log("selected plan", selectedPlan);
     console.log("selected user", user);

     if (user && selectedPlan){
      navigate('/success')
     }
  };

  return (
    <div className="row row-cols-1 row-cols-md-3 g-4 mt-3">
      {/* {Free plan} */}
      <div className="col">
        <div className="card mb-3">
          <div className="card-header bg-primary text-white">
            {" "}
            <h4 className="my-0 font-weight-normal">Free Trial</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">
              Expires in<small className="text-muted"> 24 hours</small>
            </h1>
            <div className="card-text">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">An item</li>
                <li className="list-group-item">A second item</li>
                <li className="list-group-item">A third item</li>
                <li className="list-group-item">A fourth item</li>
                <li className="list-group-item">And a fifth one</li>
              </ul>
            </div>
            <div>
              <button
                type="button"
                className="btn btn-lg btn-block btn-outline-primary"
                onClick={() => handleSelectPlan("free")}
              >
                Select plan
              </button>
            </div>
            {selectedPlan == "free" && (
              <div className="mt-3">
                <button
                  type="button"
                  className="btn btn-lg btn-block btn-primary"
                  onClick={createFreeUser}
                >
                  Create Account
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* {Basic plan}
      <div className="col">
        <div className="card mb-3">
          <div className="card-header bg-primary text-white">
            {" "}
            <h4 className="my-0 font-weight-normal">Basic</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">
              Rs 149<small className="text-muted">/day</small>
            </h1>
            <div className="card-text">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">An item</li>
                <li className="list-group-item">A second item</li>
                <li className="list-group-item">A third item</li>
                <li className="list-group-item">A fourth item</li>
                <li className="list-group-item">And a fifth one</li>
              </ul>
            </div>
            <div>
              <button
                type="button"
                className="btn btn-lg btn-block btn-outline-primary"
                onClick={() => handleSelectPlan("basic")}
              >
                Select plan
              </button>
            </div>
            {selectedPlan=='basic' && (
              <div className="mt-3">
                <Link to={`/checkout`}>
                  <button
                    type="button"
                    className="btn btn-lg btn-block btn-primary"
                  >
                    Pay now
                  </button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div> */}

      {/* {Pro plan} */}
      <div className="col">
        <div className="card mb-3">
          <div className="card-header bg-primary text-white">
            {" "}
            <h4 className="my-0 font-weight-normal">Pro</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">
              Rs 999<small className="text-muted">/week</small>
            </h1>
            <div className="card-text">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">An item</li>
                <li className="list-group-item">A second item</li>
                <li className="list-group-item">A third item</li>
                <li className="list-group-item">A fourth item</li>
                <li className="list-group-item">And a fifth one</li>
              </ul>
            </div>
            <div>
              <button
                type="button"
                className="btn btn-lg btn-block btn-outline-primary"
                onClick={() => handleSelectPlan("pro")}
              >
                Select plan
              </button>
            </div>
            {selectedPlan == "pro" && (
              <div className="mt-3">
                <Link to={`/checkout`}>
                  <button
                    type="button"
                    className="btn btn-lg btn-block btn-primary"
                  >
                    Pay now
                  </button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* {Advvanced plan} */}
      <div className="col">
        <div className="card mb-3">
          <div className="card-header bg-primary text-white">
            {" "}
            <h4 className="my-0 font-weight-normal">Advanced</h4>
          </div>
          <div className="card-body">
            <h1 className="card-title pricing-card-title">
              Rs 3499<small className="text-muted">/mo</small>
            </h1>
            <div className="card-text">
              <ul className="list-group list-group-flush">
                <li className="list-group-item">An item</li>
                <li className="list-group-item">A second item</li>
                <li className="list-group-item">A third item</li>
                <li className="list-group-item">A fourth item</li>
                <li className="list-group-item">And a fifth one</li>
              </ul>
            </div>

            <div>
              <button
                type="button"
                className="btn btn-lg btn-block btn-outline-primary"
                onClick={() => handleSelectPlan("advanced")}
              >
                Select plan
              </button>
            </div>
            {selectedPlan == "advanced" && (
              <div className="mt-3">
                <Link to={`/checkout`}>
                  <button
                    type="button"
                    className="btn btn-lg btn-block btn-primary"
                  >
                    Pay now
                  </button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
