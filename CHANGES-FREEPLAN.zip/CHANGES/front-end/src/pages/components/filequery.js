import React, { useState } from "react";
import axios from "axios";

const Filequery = ({ fileId, newfileQuery, newqueryResponse }) => {
  // const unique_fileid = fileId;
  // //console.log('Answer box------', unique_fileid);

  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);

  const queryURL = process.env.REACT_APP_FILE_QUERY_URL;

  const postData = {
    id: fileId,
    query: inputText,
  };

  // Set the Content-Type header to application/json
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const handletextChange = (event) => {
    // Update the inputText state with the value from the input field
    setInputText(event.target.value);
  };

  const handleSubmitQuery = async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior
    newfileQuery(inputText);
    setLoading(true);

    try {
      const response = await axios.post(queryURL, postData, config);
      const respdata = await response.data;
      console.log(respdata);
      setInputText("");
      newqueryResponse(respdata.response);
      // console.log('........', newqueryResponse)
      setLoading(false);
    } catch (e) {
      console.log(e);
    }
  };

  const isSubmitDisabled = !fileId;

  return (
    <div className="row mt-2 justify-content-end ">
      <div className="col-md-9 text-center">
        <div className="card">
          <div className="card-body">
            <div className="pt-4 pb-2">
              <h5 className="card-title text-center pb-0 fs-4 text-decoration-underline">
                Ask your Questions...
              </h5>
            </div>
            <form onSubmit={handleSubmitQuery}>
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Ask about your document"
                  aria-label="Username"
                  aria-describedby="basic-addon1"
                  onChange={handletextChange}
                  value={inputText}
                />
                <button
                  className="btn btn-primary"
                  type="submit"
                  id="inputGroupFileAddon04"
                  disabled={loading || isSubmitDisabled}
                >
                  {loading ? "Generating Result..." : "Submit"}
                </button>
              </div>
            </form>
            {/* <div>{unique_fileid && <h4>{unique_fileid}</h4>}</div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Filequery;
