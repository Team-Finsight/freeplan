import React, { useState } from "react";
import Fileupload from "./fileupload";
import Fileanswer from "./fileanswer";
import Filequery from "./filequery";

const Filesection = () => {
  const [fileId, setfileId] = useState("");
  const [newQuery, setnewQuery] = useState("");
  const [newResponse, setnewResponse] = useState("");

  const setnewFileId = (newId) => {
    setfileId(newId);
  };

  const setNewfileQuery = (query) => {
    setnewQuery(query);
    //console.log('from filesection', newQuery);
  };

  const setnewqueryResponse = (response) => {
    setnewResponse(response);
  };

  return (
    <div className="container" style={{marginTop:'5%'}}>
      <div className="row justify-content-center">
        <Fileupload onFileIdChange={setnewFileId} />
        <Fileanswer addnewQuery={newQuery} addnewResponse={newResponse} />
        <Filequery
          fileId={fileId}
          newfileQuery={setNewfileQuery}
          newqueryResponse={setnewqueryResponse}
        />
      </div>
      
    </div>
  );
};

export default Filesection;
