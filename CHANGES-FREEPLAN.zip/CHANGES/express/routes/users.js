var express = require("express");
var router = express.Router();
var User = require("../model/user.js");
const { hashPassword, verifyPassword } = require("../bcryptUtils.js");

/* GET users listing. */
router.get("/get", function (req, res, next) {
  res.send("respond with a resource");
});

//Verifying Email already exists based on Email
// router.post("/verify", async function (req, res, body) {
//   console.log(".......", req.body);
//   try {
//     const {
//       user: { name, email, password },
//     } = req.body;

//     // Check if the email already exists in the database
//     const existingUser = await User.findOne({ email });

//     if (existingUser) {
//       return res.status(200).json({
//         success: false,
//         message: "Email already exists",
//       });
//     } else {
//       return res.status(200).json({
//         success: true,
//       });
//     }
//   } catch (e) {
//     console.error("Error:", e);
//     res.status(500).json({
//       success: false,
//       message: "Internal Server Error",
//     });
//   }
// });

//Verify user expiration time in Reg form
router.post("/verify", async function (req, res, body) {
    console.log(".......", req.body);
    try {
      const {
        user: { name, email, password },
      } = req.body;
  
      // Check if the email already exists in the database
      const existingUser = await User.findOne({ email });
  
      if (existingUser) {
        // Check expiration time
        const currentTime = new Date();
        if (existingUser.expirationTime && existingUser.expirationTime > currentTime) {
          // Expiration time has not passed
          return res.status(200).json({
            success: false,
            message: "User already exists",
          });
        }
      }
        return res.status(200).json({
        success: true,
      });
    } catch (e) {
      console.error("Error:", e);
      res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  });

// SAVE / UPDATE during Upgrade user details
// Free User logic added
router.post("/save", async function (req, res) {
  try {
    const {
      user: { name, email, password },
      selectedPlan,
    } = req.body;

    // Find the user by email
    const existingUser = await User.findOne({ email });

    // Helper function to check if a user has an active subscription
    function hasActiveSubscription(user) {
      return user.expirationTime > new Date();
    }

    // Helper function to check if a user has an expired subscription
    function hasExpiredSubscription(user) {
      return user.expirationTime <= new Date();
    }

    // Check if the user has an active subscription (not expired)
    if (existingUser && hasActiveSubscription(existingUser) && !hasExpiredSubscription(existingUser)) {
      return res.status(400).json({
        success: false,
        message: "User has an active subscription. Cannot avail the free service.",
      });
    }

    // Check if the user has already availed the free service
    if (existingUser && existingUser.selectedPlan === "free") {
      return res.status(400).json({
        success: false,
        message: "User has already availed the free service. Please buy a Subscription",
      });
    }

    // Check if the user has an expired subscription
    if (existingUser && hasExpiredSubscription(existingUser) && selectedPlan === "free") {
      return res.status(400).json({
        success: false,
        message: "User already has an expired subscription. Cannot avail the free service. Please buy a Subscription",
      });
    }

    // Save the updated user to the database using save()
    if (existingUser) {
      existingUser.name = name;
      existingUser.selectedPlan = selectedPlan;

      // Update the password if provided
      if (password) {
        const { hash, salt } = await hashPassword(password);
        existingUser.hashedPassword = hash;
        existingUser.salt = salt;
      }

      // Update payment time and expiration time based on the selected plan
      const paymentTime = new Date();
      switch (selectedPlan) {
        case "free":
          existingUser.expirationTime = new Date(paymentTime.getTime() + 1 * 24 * 60 * 60 * 1000); 
          break;
        case "basic":
          existingUser.expirationTime = new Date(paymentTime.getTime() + 1 * 24 * 60 * 60 * 1000);
          break;
        case "pro":
          existingUser.expirationTime = new Date(paymentTime.getTime() + 7 * 24 * 60 * 60 * 1000);
          break;
        case "advanced":
          existingUser.expirationTime = new Date(paymentTime.getTime() + 30 * 24 * 60 * 60 * 1000);
          break;
        default:
          // Handle invalid plan
          return res.status(400).json({
            success: false,
            message: "Invalid plan selected",
          });
      }

      existingUser.paymentTime = paymentTime;

      // Save the updated user to the database using save()
      await existingUser.save();

      return res.status(200).json({
        success: true,
        message: "User information updated successfully!",
        user: existingUser,
      });
    } else {
      // User does not exist, create a new user

      const { hash, salt } = await hashPassword(password);

      // Set payment time
      const paymentTime = new Date();

      // Calculate expiration time based on the selected plan
      let expirationDuration;
      switch (selectedPlan) {
        case "free":
          expirationDuration = 1; // 1 day
          break;
        case "basic":
          expirationDuration = 1; // 1 day
          break;
        case "pro":
          expirationDuration = 7; // 7 days
          break;
        case "advanced":
          expirationDuration = 30; // 30 days
          break;
        default:
          // Handle invalid plan
          return res.status(400).json({
            success: false,
            message: "Invalid plan selected",
          });
      }

      const expirationTime = new Date(
        paymentTime.getTime() + expirationDuration * 24 * 60 * 60 * 1000
      );

      // Create a new user instance with selected plan, payment time, and expiration time
      const newUser = new User({
        name,
        email,
        hashedPassword: hash,
        salt,
        selectedPlan,
        paymentTime,
        expirationTime,
      });

      // Save the new user to the database using save()
      await newUser.save();

      return res.status(200).json({
        success: true,
        message: "User created successfully!",
        user: newUser,
      });
    }
  } catch (error) {
    console.error("Error:", error);

    if (error.name === "ValidationError") {
      // Handle validation errors
      return res.status(400).json({
        success: false,
        message: "Validation failed",
        errors: error.errors,
      });
    } else {
      // Handle other errors
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  }
});


// // Saving user details
// router.post("/save", async function (req, res, body) {
//   console.log("-----", req.body);
//   try {
//     const {
//       user: { name, email, password },
//       selectedPlan,
//     } = req.body;

//     // console.log("####", password);
//     // console.log("1111", email);
//     // console.log("2222", selectedPlan);

//     const { hash, salt } = await hashPassword(password);
//     //console.log("Generated hash and salt:", { hash, salt });

//     // Set payment time
//     const paymentTime = new Date();

//     // Calculate expiration time based on the selected plan
//     let expirationDuration;
//     switch (selectedPlan) {
//       case "basic":
//         expirationDuration = 1; // 1 day
//         break;
//       case "pro":
//         expirationDuration = 7; // 7 days
//         break;
//       case "advanced":
//         expirationDuration = 30; // 30 days
//         break;
//       default:
//         // Handle invalid plan
//         res.status(400).json({
//           success: false,
//           message: "Invalid plan selected",
//         });
//         return;
//     }

//     const expirationTime = new Date(
//       paymentTime.getTime() + expirationDuration * 24 * 60 * 60 * 1000
//     );

//     // Create a new user instance with selected plan and expiration time
//     const user = new User({
//       name,
//       email,
//       hashedPassword: hash,
//       salt,
//       selectedPlan,
//       paymentTime,
//       expirationTime,
//     });

//     // Save the user to the database
//     await user.save();

//     res.status(200).json({
//       success: true,
//       message: "Data saved to the server successfully!",
//     });
//   } catch (error) {
//     console.error("Error:", error);

//     if (error.name === "ValidationError") {
//       // Handle validation errors
//       res.status(400).json({
//         success: false,
//         message: "Validation failed",
//         errors: error.errors,
//       });
//     } else if (error.name === "MongoError" && error.code === 11000) {
//       // Handle duplicate key (unique index) violation
//       res.status(409).json({
//         success: false,
//         message: "Duplicate entry",
//         error: error.message,
//       });
//     } else {
//       // Handle other errors
//       res.status(500).json({
//         success: false,
//         message: "Internal Server Error",
//         error: error.message,
//       });
//     }
//   }
// });

module.exports = router;
